# **ShadowMario README**

## **Overview**

ShadowMario is a Java-based game built using Java 17+.

---

## **Windows Users**

### **Option 1: Run the EXE (Recommended)**

1. Open the folder where `ShadowMario.exe` is located.
2. Double-click **`ShadowMario.exe`** to start the game.
3. Enjoy the game! ✅

> ⚠️ If the game fails to launch, make sure Java 17+ is installed.

### **Option 2: Run the JAR (if you don’t have the EXE)**

1. Make sure **Java 17+** is installed:
   [https://adoptium.net/temurin/releases/](https://adoptium.net/temurin/releases/)
2. Open **Command Prompt** in the folder with `ShadowMario.jar`.
3. Run the command:

```bat
java -jar ShadowMario.jar
```

4. The game will launch.

---

## **macOS Users**

### **Run the JAR**

1. Make sure **Java 17+** is installed.
   [https://adoptium.net/temurin/releases/](https://adoptium.net/temurin/releases/)
2. Open **Terminal**.
3. Navigate to the folder containing `ShadowMario.jar`:

```bash
cd /path/to/ShadowMario
```

4. Run the game:

```bash
java -jar ShadowMario.jar
```

5. The game window should open.

---

## **Controls**

-   Arrow keys → Move
-   Space → Jump
-   Esp → Exit

---

## **Known Issues**

-   On Windows, if using `.jar` directly, Java 17+ must be installed.
-   On macOS, double-clicking JAR may not work in some Finder configurations — use Terminal.
