# 🃏 HiFive: A Digital Card Game

A personal Java-based simulation of a strategic turn-based card game—**HiFive**—where human and AI players compete using diverse strategies. Built with modular object-oriented design, this project is fully configurable, testable, and extensible.

---

## 🎲 Rules

### 🃏 Setup

- Standard 52-card deck: 4 suits (♠ ♥ ♦ ♣), 13 ranks (A–K)
- Each rank has **game** and **score** values:

| Card | Game Value (summing) | Score Value |
| ---- | -------------------- | ----------- |
| 2–10 | As-is                | As-is       |
| A    | 0 or 1               | 1           |
| J    | 10                   | 11          |
| Q    | 11                   | 12          |
| K    | 12 or 13             | 13          |

> _Game values are flexible; score values are fixed._

---

### 🎯 Objective

Reach a total of **exactly 5** using public/private cards after 4 rounds.

---

### 🔁 Gameplay Flow

1. **Initial Deal**
    - 52 shuffled cards
    - 2 public face-up cards
    - 2 private cards to each player

2. **Rounds** (4 total)
    - Each player draws 1 card, then discards 1 of their 5
    - Discards are visible to all
    - Turns proceed clockwise from Player 0

3. **Scoring**
    - Use 2 private or 1 private + 1 public to sum to 5

---

### 🏆 Scoring Logic

| Case                    | Outcome                           |
| ----------------------- | --------------------------------- |
| One player sums to 13   | That player scores **100**        |
| No one sums to 13       | Score = (value × suit-multiplier) |
| Multiple players get 13 | Highest scoring option            |

_Suit multipliers: ♠=×4, ♥=×3, ♦=×2, ♣=×1_

---

## 👨‍👩‍👧‍👦 Player Types

- **HumanPlayer** – manual
- **RandomPlayer** – random strategy
- **BasicPlayer** – simple heuristics
- **CleverPlayer** – predictive memory-based strategy

## ✅ Requirements

- Java 17+
- Gradle 8+
- IDE or CLI (IntelliJ preferred)

### ▶️ Run the Game

To run the game locally, doube click the file `HiFive.jar`
